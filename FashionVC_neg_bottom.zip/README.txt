fashionvc_5000neg.csv Readme

1. Dataset Overview

This README primarily describes the newly added fashionvc_5000neg.csv dataset, which contains 5000 manually annotated negative bottom samples by three annotators. This dataset is intended for further research and is applicable to areas such as fashion matching, computer vision, and recommendation systems.

2. Data Source

While the original dataset provided by FashionVC remains unchanged, this dataset extends the existing data by adding 5000 manually annotated negative bottom samples. The goal is to enhance research on negative matching and provide more precise training objectives.

3. Annotation Process

The annotation process of this dataset is as follows:

Annotator Background: The annotators are professionals with over ten years of experience in online fashion shopping, ensuring that the annotations are closely aligned with practical applications.

Annotation Criteria: Based on outfit compatibility principles, bottoms that are deemed incompatible with the given tops are selected as negative samples.

Annotation Mechanism: A strict annotation rule is applied, requiring each sample to be reviewed by three annotators. If any annotator disagrees with the classification, the sample is discarded to ensure annotation consistency and accuracy.

Final Selection: Only 5000 negative bottom samples that have unanimous agreement among all three annotators are retained to ensure high data quality.

4. Dataset Structure

This dataset contains the following fields:

id: Unique identifier.

top: Corresponding top ID from the original FashionVC dataset.

bottom: Corresponding bottom ID from the original FashionVC dataset.

5. Applications

This dataset can be used in the following research and applications:

Fashion Matching and Recommendation: Training machine learning models to distinguish between compatible and incompatible outfits.

Multimodal Learning: Enhancing model understanding of outfit compatibility through image and annotation data.

Adversarial Learning: Generating challenging negative samples to improve the robustness of recommendation systems.

Fashion Data Analysis: Analyzing incorrect outfit pairings across different clothing categories.

6. Download and Usage

This dataset is available for academic research under the following conditions:

Restricted to academic research and non-commercial use.

Proper citation of the dataset name and source is required.

Any modifications or extensions should be explicitly documented to ensure traceability.